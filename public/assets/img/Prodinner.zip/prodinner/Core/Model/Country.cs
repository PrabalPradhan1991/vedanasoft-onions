namespace Omu.ProDinner.Core.Model
{
    public class Country : DelEntity
    {
        public string Name { get; set; }
    }
}