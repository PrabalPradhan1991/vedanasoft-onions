namespace Omu.ProDinner.Core.Model
{
    public class Feedback : Entity
    {
        public string Comments { get; set; }
    }
}