namespace Omu.ProDinner.Core.Model
{
    public interface IDel
    {
        bool IsDeleted { get; set; }
    }
}