namespace Omu.ProDinner.Core.Model
{
    public class Entity
    {
        public int Id { get; set; }
    }
}