namespace Omu.ProDinner.WebUI.ViewModels.Input
{
    public class LookupPopupInput
    {
        public string Search { get; set; }
    }
}