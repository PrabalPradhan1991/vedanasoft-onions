namespace Omu.ProDinner.WebUI.ViewModels.Display
{
    public class ClientDict
    {
        public string GridInfo { get; set; }

        public string Select { get; set; }

        public string SearchForRes { get; set; }

        public string Searchp { get; set; }

        public string[] Months { get; set; }

        public string[] Days { get; set; }
    }
}