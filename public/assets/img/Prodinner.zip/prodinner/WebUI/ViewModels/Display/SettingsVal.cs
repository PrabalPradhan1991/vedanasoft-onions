namespace Omu.ProDinner.WebUI.ViewModels.Display
{
    public class SettingsVal
    {
        public string Theme { get; set; }
    }
}