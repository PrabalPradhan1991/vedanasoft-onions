using System.Web.Mvc;

namespace Omu.ProDinner.WebUI.Controllers
{
    public class NavController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}