namespace Omu.ProDinner.Infra
{
    public enum ChangeType
    {
        Undefined = 0,
        Create = 1,
        Edit = 2,
        Delete = 3
    }
}